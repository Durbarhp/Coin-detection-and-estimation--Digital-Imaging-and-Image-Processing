%A function for image features
%features are given
function image_features = Image_features(c, r, Img, updated_coordinate)
%c is the center point
% r is radius
%updated coordinate after scaling the image after calibration
   
 
    % convert image to hsv
    hsv_Img = rgb2hsv(Img);
    
    % Calculate diameter d
    %diameter= 2*r here updated coordinate point is also multiplied for
    %accurate diameter

    d = 2 * updated_coordinate * r;
    
    % hues and saturation points 
    hue = zeros(size(Img, 1), size(Img, 2));
    saturation = zeros(size(Img, 1), size(Img, 2));
    
    % here there are two types of saturations
    %Inner and outer
    %calculate inner and outer saturation
   
    Inner_saturation = zeros(0, 1);
    Outer_saturation = zeros(0, 1);
    
    % Repeat the process until the distance is calculated
    % Here two coordinates are taken m, n
    %distance are calculated using sum of squared distance


   % Loop through each row (m) of the HSV image
for m = 1:size(hsv_Img, 1)
    % Loop through each column (n) of the HSV image
    for n = 1:size(hsv_Img, 2)
        % Calculate squared distance from the current pixel to the center point (c)
        distance = (n - c(1))^2 + (m - c(2))^2;

        % Check if the pixel is within the specified circular region
        if distance <= r^2
            % Extract hue and saturation features from the HSV image
            hue(m, n) = hsv_Img(m, n, 1);
            saturation(m, n) = hsv_Img(m, n, 2);

            % Categorize pixels based on different distance thresholds
            if distance <= (0.70 * r)^2
                % Pixels within 70% of the radius contribute to Inner_saturation
                Inner_saturation(end + 1) = hsv_Img(m, n, 2);
            elseif distance <= (0.90 * r)^2
                % Pixels within 90% of the radius but outside the 70% threshold contribute to Outer_saturation
                Outer_saturation(end + 1) = hsv_Img(m, n, 2);
            end
        end
    end
end

    
    % Calculate hue feature
    %sum of binary singleton expansion over element wise multiplication
    hue = sum(bsxfun(@times, hue, saturation)) / sum(saturation); %Binary Singleton Expansion Function
    
    % canculate the differenece
    difference = mean(Inner_saturation) - mean(Outer_saturation);
    
    % Calculate average hue and saturation features
    Hue = mean(hue(:));
    Saturation = mean(saturation(:));
    
    image_features = [d hue difference Hue Saturation];
end
