% Original measurements
original_data = [
    1, 1, 1, 1, 1, 1;
    3, 1, 0, 1, 0, 0;
    1, 0, 0, 5, 1, 1;
    0, 0, 0, 3, 1, 3;
    0, 1, 0, 4, 1, 3;
    0, 3, 0, 1, 0, 2;
    0, 1, 0, 3, 0, 0;
    0, 0, 1, 4, 0, 3;
    0, 0, 0, 0, 1, 3;
    0, 0, 1, 4, 0, 0;
    0, 3, 1, 5, 0, 0;
    0, 3, 1, 1, 0, 0
];

% Provided results
results_data = [
    2, 0, 1, 1, 1, 1;
    3, 1, 0, 1, 0, 0;
    1, 0, 0, 5, 1, 1;
    0, 0, 0, 3, 1, 3;
    0, 1, 0, 4, 1, 3;
    0, 3, 0, 1, 0, 2;
    0, 1, 0, 3, 0, 0;
    0, 0, 1, 4, 0, 3;
    0, 0, 0, 0, 1, 3;
    0, 0, 1, 4, 0, 0;
    0, 3, 1, 5, 0, 0;
    0, 3, 1, 1, 0, 0
];

% Calculate Euclidean distance for each pair of measurements and results
error_distances = sqrt(sum((original_data - results_data).^2, 2));

% Display the error distances
disp('Error Distances:');
disp(error_distances);

% Calculate the overall mean error
mean_error = mean(error_distances);
disp(['Mean Error: ', num2str(mean_error)]);

% Define a threshold for considering predictions as correct
threshold = 1.0; % Adjust as needed

% Count the number of correct predictions based on the threshold
correct_predictions = sum(error_distances <= threshold);

% Calculate accuracy
accuracy = correct_predictions / size(original_data, 1) * 100;

% Display the accuracy
disp(['Accuracy: ', num2str(accuracy), '%']);
