%The input for the estim_coins(measurement, bias, dark, flat) are the four images (measurement, bias, dark, flat)
function [coins] = estim_coins(measurement, bias, dark, flat)
 
%if we calculate the image area using 4*pi*r^2
%here r is radius
%we get the coin measurement area

%let's calculate the sizes of dark, bias, flat and raw images

%521/size(measurement)
    measurement = imresize(measurement, 520/size(measurement, 1)); 
%disp(measurement);

       %calculate dark image imersize
    dark = imresize(dark, 520/size(dark, 1));
    %disp(dark);
         %calculate flat image imersize
    flat = imresize(flat, 520/size(flat, 1));
    %disp(flat);
       %calculate bias image imersize
    bias = imresize(bias, 520/size(bias, 1));

    %disp(bias);

    % Detect checkerboard points

    %detect checkerboard points is matlab function
   
    [checkerboardPoints, boardSize] = detectCheckerboardPoints(measurement, 'PartialDetections', false);
    
    % Calibrate intensity of the images using the calibration measurements

    %calibration measurements of dark, bias and flat field images
    calibratedImage = calibration_measurement(measurement, bias, dark, flat, checkerboardPoints, boardSize);
    
    % Now let's try detecting circular objects to identify coins

    [centers, radii] = circle_detection(calibratedImage, checkerboardPoints, boardSize);
    
    % After calibration we need to scale the image for real world picture
    % scale
    updated_imagepoint = scale_DHP(checkerboardPoints, boardSize);

    % Let's store the coin coints
    coins = zeros(1, 6);

    % let's determine the size of the objects
    n = size(centers, 1);

    % Iterate through detected, iteration will be the number of objects

    %Clasiify coins in each iteration
    for j = 1:n
        % Extract features for the current circular object
        features = Image_features(centers(j, :), radii(j), calibratedImage, updated_imagepoint);
        
        % Classify the coins using coin class function
        coinClass = coin_class(features);
     
        % Only if the coin class is more than zero then go to next
        if coinClass >  0
            coins(coinClass) = coins(coinClass) + 1;
        end
    end
end
