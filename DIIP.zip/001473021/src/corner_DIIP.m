function [Top_Corner_left, Top_right_corner, Bottom_left_corner, Bottom_right_corner] = corner_DIIP(checkerboardPoints, boardSize)
   
% Let's assume the checker boarm mxn matrix
%rows=m, coloumn=n
    [m, n] = size(boardSize);

% Here checkerboard is either 2x1 or 1x2 dimensional
%let's check
    if ~(m == 1 && n == 2) && ~(m == 2 && n == 1)
        error('Checker board should be 2x1 or 1x2');
    end

    % we need to update height and width to adjust heights and widths

    height_updated = boardSize(1) - 2;
    width_updated = boardSize(2) - 2;

    % the board have two types of corners: inner and outer
    %Let us find the points for all the inner
      %inner top left
    Top_left_in = checkerboardPoints(1, :);

    %bottom left 
    bottom_left_In = checkerboardPoints(1 + height_updated, :);

    %Top right
    Top_right_in = checkerboardPoints(end - height_updated, :);

    %inner bottom Right
    Bottom_right_in = checkerboardPoints(end, :);

    % Now estimate and calculate outer board too
% 4 corners
% Top corner left
    Top_Corner_left = Top_left_in + (Top_left_in - Top_right_in) / width_updated + (Top_left_in - bottom_left_In) / height_updated;
    %Bottom Left Corner
    Bottom_left_corner = bottom_left_In + (bottom_left_In - Bottom_right_in) / width_updated + (bottom_left_In - Top_left_in) / height_updated;

    %Right bottom corner
    Bottom_right_corner = Bottom_right_in + (Bottom_right_in - bottom_left_In) / width_updated + (Bottom_right_in - Top_right_in) / height_updated;

    %Top right corner
    Top_right_corner = Top_right_in + (Top_right_in - Top_left_in) / width_updated + (Top_right_in - Bottom_right_in) / height_updated;
end
