function scale = scale_DHP(checkerboardPoints, boardSize)
   
    
    % Extract the number of rows and columns from the boardSize
    [rows, cols] = size(boardSize);
    
    % Check if the boardSize is valid (2x1 or 1x2 matrix)
    if ~(rows == 1 && cols == 2) && ~(rows == 2 && cols == 1)
        error('Invalid boardSize. It should be a 1x2 or 2x1 matrix.');
    end
    
    % The size of each square (both black and white) is 12.5mm*12.5mm.
    length = 12.5;  % Given in the moodle
    
    % Image-based measurements estimation
    [topLeft, topRight, bottomLeft, bottomRight] = corner_DIIP(checkerboardPoints, boardSize);
    pixel_image = mean([sqrt(sum((topLeft - bottomLeft).^2)) / boardSize(1); sqrt(sum((topRight - bottomRight).^2)) / boardSize(1)]);
    
    % Scale estimation
    scale = length / pixel_image;
end
