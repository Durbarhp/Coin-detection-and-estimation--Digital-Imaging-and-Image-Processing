%This function is used to calibrate Image
% measurement is the measurement of the raw image taken for claibration

%mean_B is the mean of the Bias images
%mean_D is the mean of the dark images
%norm_F is the normalized flat field images

function calibratedImage = calibration_measurement(measurement, mean_B, mean_D, norm_F, checkerboardPoints, boardSize)
    
%Norm_f_noboard is the norm_F value ; flatfield without chcekerboard
    Norm_f_noboard = replace_Dhp(norm_F, checkerboardPoints, boardSize);
    
    
    % Using the moodle formula
    calibratedImage = ((measurement - mean_B - mean_D) ./ Norm_f_noboard);
end