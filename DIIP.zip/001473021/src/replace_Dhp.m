%function for masking the checkerboard with masked image

function Image_mask = replace_Dhp(image, checkerboardPoints, boardSize)
    % Detect the four corners of the checkerboard using detectCornerPoints
    [topLeft, topRight, bottomLeft, bottomRight] = corner_DIIP(checkerboardPoints, boardSize);

    % Define a polygon using the detected corners
    Polygon = [topLeft; bottomLeft; bottomRight; topRight];

    % Calculate the mean intensity of a small region (5x5) at the top-left corner
    Image_mean = mean2(image(1:5, 1:5, :));

    % Create a binary mask for the specified region of the checkerboard
    binary2D = poly2mask(Polygon(:, 1), Polygon(:, 2), size(image, 1), size(image, 2));

    % Replicate the 2D mask to make it 3D for color images
    color_3D = repmat(binary2D, [1, 1, size(image, 3)]);

    % Create a copy of the original image to apply the mask
    Image_mask = image;

    % Replace values in the specified region with the mean intensity value
    Image_mask(color_3D) = Image_mean;
end
