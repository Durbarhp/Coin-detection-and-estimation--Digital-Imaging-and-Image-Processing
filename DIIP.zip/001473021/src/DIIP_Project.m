% DIIP Project
% Experiment_DIIP
function DIIP_Project()
    % Specify directory paths
    %measDir = 'E:\DIIP_pr\exp\DIIP-images-measurements-1\DIIP-images\Measurements\_DSC1772.JPG';
    biasDir = 'E:\DIIP_pr\exp\DIIP-images-bias\DIIP-images\Bias';
    darkDir = 'E:\DIIP_pr\exp\DIIP-images-dark\DIIP-images\Dark';
    flatDir = 'E:\DIIP_pr\exp\DIIP-images-flat\DIIP-images\Flat';

    % Read images using imread function

 %Read the bias images
    bias1 = imread(fullfile(biasDir, '_DSC1722.JPG'));
    bias2 = imread(fullfile(biasDir, '_DSC1723.JPG'));
    bias3 = imread(fullfile(biasDir, '_DSC1724.JPG'));
    bias4 = imread(fullfile(biasDir, '_DSC1725.JPG'));
    bias5 = imread(fullfile(biasDir, '_DSC1726.JPG'));

    %Read the dark images
    dark1 = imread(fullfile(darkDir, '_DSC1762.JPG'));
    dark2 = imread(fullfile(darkDir, '_DSC1763.JPG'));
    dark3 = imread(fullfile(darkDir, '_DSC1764.JPG'));
    dark4 = imread(fullfile(darkDir, '_DSC1765.JPG'));
    dark5 = imread(fullfile(darkDir, '_DSC1766.JPG'));
%calculate mean of the bias images and mean of the dark images
    % Calculate mean_B and mean_D
    mean_B = uint8(mean(cat(3, bias1, bias2, bias3, bias4, bias5), 3));
    mean_D = uint8(mean(cat(3, dark1, dark2, dark3, dark4, dark5), 3));
%mean of the flat fields
      % Calculate norm_F
    flat1 = imread(fullfile(flatDir, '_DSC1767.JPG'));
    flat2 = imread(fullfile(flatDir, '_DSC1768.JPG'));
    flat3 = imread(fullfile(flatDir, '_DSC1769.JPG'));
    flat4 = imread(fullfile(flatDir, '_DSC1770.JPG'));
    flat5 = imread(fullfile(flatDir, '_DSC1771.JPG'));

    % Convert flat field images into double type
    flat_images = double(cat(3, flat1, flat2, flat3, flat4, flat5));

    % Calculate norm_F and convert type into unit8
    norm_F = uint8(mean(flat_images, 3) / max(flat_images(:)));

    %load the image for calibration
    %take one image for experiment
Image_raw = 'E:\DIIP_pr\exp\DIIP-images-measurements-1\DIIP-images\Measurements\_DSC1772.JPG';

%read the raw image
image_measurement = imread(Image_raw);

%calculate claibrated image from the formula got from moodle
calibrated_image = (image_measurement - mean_B - mean_D) ./ norm_F;

%plot the image in a figure
figure(1);
%show the both images before and after calibration
subplot(121); imshow(uint8(image_measurement)); title('Original Image');
subplot(122);imshow(uint8(calibrated_image)); title('Calibrated Image before detect checkerboard points');
%use detect checkerboard points: matlab function
[checkerboardPoints, boardSize] = detectCheckerboardPoints(image_measurement, 'PartialDetections', false);

% use the calibration_measurement function 
Image_calibrated = calibration_measurement(image_measurement, mean_B, mean_D, norm_F, checkerboardPoints, boardSize);

%plot the images
figure(2);
subplot(121); imshow(uint8(image_measurement)); title('Original Raw Image');
subplot(122); imshow(Image_calibrated); title('Calibrated Image');

% Save the image in the directory
imwrite(Image_calibrated, 'E:\DIIP_pr\exp\Finaldhp7.jpg');

%Now let's estimate the coins in the images
%add paths
addpath E:\DIIP_pr\exp\DIIP-images-flat\DIIP-images\Flat
addpath E:\DIIP_pr\exp\DIIP-images-dark\DIIP-images\Dark
addpath E:\DIIP_pr\exp\DIIP-images-bias\DIIP-images\Bias
addpath E:\DIIP_pr\exp\DIIP-images-measurements-1\DIIP-images\Measurements
addpath E:\DIIP_pr\exp\DIIP-images-measurements-2\DIIP-images\Measurements

% Detect coins in a calibrated image.

%Image_detect is the combination of images to be detected
%Let's create an array to store all the images available for measurements
Image_detect = ["_DSC1772.JPG" "_DSC1773.JPG" "_DSC1774.JPG" '_DSC1775.JPG' '_DSC1776.JPG' '_DSC1777.JPG' '_DSC1778.JPG' '_DSC1779.JPG' '_DSC1780.JPG' '_DSC1781.JPG' '_DSC1782.JPG' '_DSC1783.JPG'];

%calculate length of the images to be detected
n=length(Image_detect);

%iteration till the length of the image
for i=1:n
    %read the ith number image
    Image_measurement = imread(Image_detect(i));

    %detect coin using estim_coins function
    detected_coins = estim_coins(Image_measurement, mean_B, mean_D, norm_F);

    %Display the results
    disp(detected_coins);
end

