% Function: calibrateAndRemoveCheckerboard
function [calibrated_image, checkboard_rmv] = calibrateAndRemoveCheckerboard(raw_image, mean_B, mean_D, norm_F)
    % Calibrate the raw image
    calibrated_image = uint8((double(raw_image) - double(mean_B) - double(mean_D)) ./ double(norm_F));

    % Checkerboard removal
    [boardPoints, boardSize] = detectCheckerboardPoints(calibrated_image, 'MinCornerMetric', 0.15);

    % Convert boardPoints to a regular matrix for indexing
    RawimgPoints = double(boardPoints);

    if length(RawimgPoints) > 0
        h = boardSize(1) - 2;
        w = boardSize(2) - 2;

        % Calculate coordinates for checkerboard corners
        dx          = RawimgPoints(1, 1) - RawimgPoints(2, 1);
        dy          = RawimgPoints(1, 2) - RawimgPoints(2, 2);
        Topleft     = [RawimgPoints(1, 1) + dx + dy, RawimgPoints(1, 2) + dx + dy];
        Topright    = [RawimgPoints(end - h + 1, 1) - dx - dy, RawimgPoints(end - h + 1, 2) + 2 * (dx + dy)];
        Bottomleft  = [RawimgPoints(boardSize(1) - 1, 1) + dx + dy, RawimgPoints(boardSize(1) - 1, 2) - dx - dy];
        Bottomright = [RawimgPoints(end, 1) - dx - dy, RawimgPoints(end, 2) - dx - dy];
    else
        % Default coordinates if checkerboard not found
        Topleft     = [0 0];
        Topright    = [0 0];
        Bottomleft  = [0 0];
        Bottomright = [0 0];
    end

    % Mask the checkerboard
    mean_intensity = median(calibrated_image(:));
    checkboard_rmv = insertShape(calibrated_image, ...
        'FilledPolygon', [Topleft; Bottomleft; Bottomright; Topright], ...
        'Color', [mean_intensity mean_intensity mean_intensity], ...
        'Opacity', 1);
end


