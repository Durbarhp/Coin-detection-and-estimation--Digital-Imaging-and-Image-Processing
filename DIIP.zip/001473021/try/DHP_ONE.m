% Main function
function DHP_ONE()
    % Specify directory paths
    measDir = 'E:\DIIP_pr\exp\DIIP-images-measurements-1\DIIP-images\Measurements\_DSC1772.JPG';
    biasDir = 'E:\DIIP_pr\exp\DIIP-images-bias\DIIP-images\Bias';
    darkDir = 'E:\DIIP_pr\exp\DIIP-images-dark\DIIP-images\Dark';
    flatDir = 'E:\DIIP_pr\exp\DIIP-images-flat\DIIP-images\Flat';

    % Read images using imread function
    meas = imread(measDir);
    bias1 = imread(fullfile(biasDir, '_DSC1722.JPG'));
    bias2 = imread(fullfile(biasDir, '_DSC1723.JPG'));
    bias3 = imread(fullfile(biasDir, '_DSC1724.JPG'));
    bias4 = imread(fullfile(biasDir, '_DSC1725.JPG'));
    bias5 = imread(fullfile(biasDir, '_DSC1726.JPG'));
    dark1 = imread(fullfile(darkDir, '_DSC1762.JPG'));
    dark2 = imread(fullfile(darkDir, '_DSC1763.JPG'));
    dark3 = imread(fullfile(darkDir, '_DSC1764.JPG'));
    dark4 = imread(fullfile(darkDir, '_DSC1765.JPG'));
    dark5 = imread(fullfile(darkDir, '_DSC1766.JPG'));

    % Calculate mean_B and mean_D
    mean_B = uint8(mean(cat(3, bias1, bias2, bias3, bias4, bias5), 3));
    mean_D = uint8(mean(cat(3, dark1, dark2, dark3, dark4, dark5), 3));

      % Calculate norm_F
    flatfield1 = imread(fullfile(flatDir, '_DSC1767.JPG'));
    flatfield2 = imread(fullfile(flatDir, '_DSC1768.JPG'));
    flatfield3 = imread(fullfile(flatDir, '_DSC1769.JPG'));
    flatfield4 = imread(fullfile(flatDir, '_DSC1770.JPG'));
    flatfield5 = imread(fullfile(flatDir, '_DSC1771.JPG'));

    % Convert flatfield images to double
    flatfield_stack = double(cat(3, flatfield1, flatfield2, flatfield3, flatfield4, flatfield5));

    % Calculate norm_F
    norm_F = uint8(mean(flatfield_stack, 3) / max(flatfield_stack(:)));



    % Output code
    raw_image = meas;
    ref_image = meas;  
    
    % Call the calibration and checkerboard removal function
    [calibrated_image, checkboard_rmv] = calibrateAndRemoveCheckerboard(raw_image, mean_B, mean_D, norm_F);

    % Display the output images
    figure;
    subplot(1, 2, 1), imshow(ref_image), title('Raw Image');
    subplot(1, 2, 2), imshow(calibrated_image), title('Calibrated Image');
    % Display the checkerboard removed image alone
    figure;
    imshow(checkboard_rmv), title('Checkerboard Removed Image');

    
    % Save the checkerboard-removed image
    imwrite(checkboard_rmv, 'E:\DIIP_pr\exp\calDHP_checkboard_removed.jpg');
end


